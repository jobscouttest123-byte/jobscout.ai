# JobScoutAI

AI-powered job scout that fetches jobs, filters them, scores them against your values, 
and sends you a daily digest via Gmail.

## Setup

1. Add secrets in GitHub → Settings → Secrets and variables → Actions:
   - `GMAIL_USER`
   - `GMAIL_PASS`
   - `OPENAI_API_KEY`
   - (optional) `OPENAI_MODEL`, `ADZUNA_ID`, `ADZUNA_KEY`

2. The workflow runs daily at 09:00 UTC (edit `.github/workflows/jobscout-daily.yml` to change).
