# JobScout-AI (Full MVP)

Cloud-friendly Python prototype that finds jobs, filters by your pay floor & type, **scores them against your values**, and emails the **top 3 per day**.

## Quick Start (Replit)
1) Upload & extract this ZIP.
2) In Console: `pip install -r requirements.txt`
3) Open `config.yaml` → set your **Mailtrap** creds under `test_email:` and leave `testing: true`.
4) Add Secrets (optional now): `OPENAI_API_KEY` (can be dummy), `ADZUNA_ID`, `ADZUNA_KEY`.
5) Run: `python daily_runner.py`
6) Check your Mailtrap inbox.

## Files
- `collectors/` — remotive & adzuna fetchers
- `core/normalize.py` — unify fields
- `core/filters.py` — salary/type/geo rules
- `core/scorer.py` — values-based LLM scorer (uses `OPENAI_API_KEY`)
- `core/emailer.py` — email sender with testing toggle
- `core/pick.py` — pick top N
- `daily_runner.py` — orchestrates the daily digest
