import smtplib
import os
from email.mime.text import MIMEText

def send_email(cfg, subject, body):
    # Always print digest for console visibility
    print("=" * 60)
    print(f"📧 EMAIL DIGEST")
    print("=" * 60)
    print(f"Subject: {subject}")
    print(f"Content:\n{body}")
    print("=" * 60)
    
    # Send real email if not in testing mode
    if not cfg.get("testing", True):
        try:
            email_config = cfg["email"]
            
            # Handle environment variable substitution
            username = os.getenv("GMAIL_USER", email_config["username"])
            password = os.getenv("GMAIL_PASS", email_config["password"])
            
            if username and password and username != "${GMAIL_USER}" and password != "${GMAIL_PASS}":
                msg = MIMEText(body, "plain")
                msg["Subject"] = subject
                msg["From"] = username
                msg["To"] = email_config["to"]
                
                with smtplib.SMTP(email_config["smtp_server"], email_config["smtp_port"]) as server:
                    server.starttls()
                    server.login(username, password)
                    server.sendmail(username, [email_config["to"]], msg.as_string())
                
                print(f"✅ Email sent successfully to {email_config['to']}!")
            else:
                print("⚠️ Gmail credentials not found in environment variables. Set GMAIL_USER and GMAIL_PASS to enable email sending.")
        except Exception as e:
            print(f"❌ Failed to send email: {e}")
            print("💡 Make sure your Gmail App Password is correct and 2FA is enabled.")
