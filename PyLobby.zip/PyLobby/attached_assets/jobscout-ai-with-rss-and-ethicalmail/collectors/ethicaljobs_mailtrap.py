import os, re, poplib, email
from email.header import decode_header
from bs4 import BeautifulSoup
MAILTRAP_POP3_HOST=os.getenv('MAILTRAP_POP3_HOST')
MAILTRAP_POP3_PORT=int(os.getenv('MAILTRAP_POP3_PORT','110'))
MAILTRAP_USER=os.getenv('MAILTRAP_USER')
MAILTRAP_PASS=os.getenv('MAILTRAP_PASS')
LINK_RE=re.compile(r"https?://(?:www\.)?ethicaljobs\.com\.au/[^\"'\s>]+", re.I)

def _decode(s):
    if not s: return ''
    parts=decode_header(s)
    return ''.join([(t.decode(enc or 'utf-8') if isinstance(t,bytes) else t) for t,enc in parts])

def _extract_links_from_html(html):
    links=set(); soup=BeautifulSoup(html or '', 'html.parser')
    for a in soup.find_all('a', href=True):
        if LINK_RE.search(a['href']): links.add(a['href'])
    return list(links)

def fetch_ethicaljobs_from_mailtrap(max_messages=50):
    jobs=[]
    if not all([MAILTRAP_POP3_HOST, MAILTRAP_USER, MAILTRAP_PASS]): return jobs
    use_ssl=(MAILTRAP_POP3_PORT==995)
    pop=poplib.POP3_SSL(MAILTRAP_POP3_HOST, MAILTRAP_POP3_PORT) if use_ssl else poplib.POP3(MAILTRAP_POP3_HOST, MAILTRAP_POP3_PORT)
    pop.user(MAILTRAP_USER); pop.pass_(MAILTRAP_PASS)
    try:
        num=len(pop.list()[1]); count=min(num, max_messages)
        for i in range(num, num-count, -1):
            raw=b"\r\n".join(pop.retr(i)[1]); msg=email.message_from_bytes(raw)
            subj=_decode(msg.get('Subject'))
            body_html=''
            for part in msg.walk():
                if part.get_content_type()=='text/html':
                    body_html=part.get_payload(decode=True).decode(part.get_content_charset() or 'utf-8', errors='ignore'); break
            for link in _extract_links_from_html(body_html):
                jobs.append({'source':'ethicaljobs_mail','title':subj or 'EthicalJobs listing','company':None,'location':None,'country':'AU','remote':None,'employment_type':None,'salary_text':None,'salary_min':None,'salary_max':None,'currency':None,'link':link,'description':'Discovered via EthicalJobs email alert','posted_at':None})
    finally:
        pop.quit()
    return jobs
