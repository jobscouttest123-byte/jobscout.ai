See conversation for setup steps. Add OPENAI_API_KEY in Secrets for scoring. Add Mailtrap POP3 creds to read EthicalJobs alerts.
