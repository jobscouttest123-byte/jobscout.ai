# JobScout-AI (MVP)

Steps:
1. Upload this ZIP to Replit
2. pip install -r requirements.txt
3. Edit config.yaml with Mailtrap creds
4. Run: python daily_runner.py
