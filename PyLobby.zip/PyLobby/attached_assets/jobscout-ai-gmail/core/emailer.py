import smtplib
from email.mime.text import MIMEText

def send_email(cfg, subject, body):
    creds = cfg['email'] if not cfg.get('testing', True) else cfg['email']
    msg = MIMEText(body, 'plain')
    msg['Subject'] = subject
    msg['From'] = creds['username']
    msg['To'] = creds['to']
    with smtplib.SMTP(creds['smtp_server'], creds['smtp_port']) as server:
        server.starttls()
        server.login(creds['username'], creds['password'])
        server.send_message(msg)
