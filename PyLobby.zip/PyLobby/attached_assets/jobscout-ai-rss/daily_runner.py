import yaml, os
from collectors.remotive import fetch_remotive
from collectors.adzuna import fetch_adzuna
from collectors.rss_feeds import fetch_from_feeds
from core.normalize import normalize
from core.filters import filter_jobs
from core.scorer import score_job
from core.pick import pick_top
from core.emailer import send_email

def load_cfg():
    with open("config.yaml") as f:
        return yaml.safe_load(f)

def load_feeds():
    try:
        with open("feeds.yaml") as f:
            data = yaml.safe_load(f) or {}
            return data.get("feeds", [])
    except FileNotFoundError:
        return []

def collect_all():
    raw = []
    raw += [(j,"remotive") for j in fetch_remotive()]
    raw += [(j,"adzuna") for j in fetch_adzuna("au")]
    raw += [(j,"adzuna") for j in fetch_adzuna("gb")]

    # RSS feeds
    for feed in load_feeds():
        url = feed.get("url")
        label = feed.get("label", "rss")
        if url:
            rss_jobs = fetch_from_feeds([url], source_label=label)
            raw += [(j, label) for j in rss_jobs]

    # Normalize API sources; pass RSS through
    jobs = []
    for j, s in raw:
        if s in ("remotive", "adzuna"):
            jj = normalize(j, s)
            if jj:
                jobs.append(jj)
        else:
            jobs.append(j)  # already standardized enough
    return jobs

def main():
    cfg = load_cfg()
    jobs = collect_all()
    jobs = filter_jobs(jobs, cfg)

    for j in jobs:
        s = score_job(j)
        j["llm_score"] = s.get("score_total", 0)
        j["llm_reasons"] = s.get("reasons", [])
        j["red_flags"] = s.get("red_flags", [])
        j["must_ask"] = s.get("must_ask", [])

    picks = pick_top(jobs, cfg.get("results_per_day", 3))

    digest = []
    digest.append("Top picks for today:\n")
    for p in picks:
        digest.append(f"{p.get('title')} @ {p.get('company')}")
        digest.append(f"Location: {p.get('location')} | Remote: {p.get('remote')} | Source: {p.get('source', 'rss')}")
        digest.append(f"Link: {p.get('link')}")
        sal_parts = []
        if p.get("salary_min") or p.get("salary_max"):
            sal_parts.append(f"{p.get('salary_min')}–{p.get('salary_max')} {p.get('currency') or ''}".strip())
        if p.get("salary_text"):
            sal_parts.append(p.get("salary_text"))
        digest.append("Salary: " + ("; ".join(sal_parts) if sal_parts else "⚠️ Not listed"))
        if p.get("llm_reasons"):
            digest.append("Why this matches your values: " + "; ".join(p.get("llm_reasons")))
        if p.get("red_flags"):
            digest.append("Red flags: " + "; ".join(p.get("red_flags")))
        if p.get("must_ask"):
            digest.append("Questions to ask: " + "; ".join(p.get("must_ask")))
        digest.append("")
    body = "\n".join(digest)
    subject = "JobScoutAI — Daily Top Picks (TEST)"
    send_email(cfg, subject, body)

if __name__ == "__main__":
    main()
