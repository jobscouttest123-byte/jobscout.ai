# JobScout-AI (with RSS)

Adds RSS/Atom collector so you can include EthicalJobs/CharityJob/WWR/etc.

## Quick Start
1) Upload & extract ZIP in Replit
2) Console: `pip install -r requirements.txt`
3) Edit `config.yaml` (Mailtrap) and `feeds.yaml` (paste your RSS URLs)
4) Run: `python daily_runner.py`
5) Check Mailtrap inbox

## Where to add feeds
Edit `feeds.yaml` and paste RSS/Atom URLs with a label:
```
feeds:
  - url: https://weworkremotely.com/categories/remote-design-jobs.rss
    label: weworkremotely
  - url: https://example.com/ethicaljobs.rss
    label: ethicaljobs
```
